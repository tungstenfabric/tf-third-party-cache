import "format";

var d3_time_formatUtc = d3_time_format.utc;
