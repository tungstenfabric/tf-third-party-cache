### Subject of the issue
Describe your issue here.

### Your environment
* version of jquery.panzoom
* version of jquery
* which browser and its version

### Steps to reproduce
Tell us how to reproduce this issue. Please provide a working demo, you can use [this template](http://jsbin.com/mofeli/edit?html,js,output) as a base.

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead
