Bezier.js
========

A node.js and client-side library for (cubic) Bezier curve work.

For a Demo and the API, hit up either http://pomax.github.io/bezierjs or read the souce (bezier.js for the library code, beziertest.js for how to use the library).

For comments and questions, [tweet at me](https://twitter.com/TheRealPomax) or just file an issue.

The code in this repo is MIT licensed.
