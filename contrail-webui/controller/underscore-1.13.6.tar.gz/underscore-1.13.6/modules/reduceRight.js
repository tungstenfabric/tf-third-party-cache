import createReduce from './_createReduce.js';

// The right-associative version of reduce, also known as `foldr`.
export default createReduce(-1);
