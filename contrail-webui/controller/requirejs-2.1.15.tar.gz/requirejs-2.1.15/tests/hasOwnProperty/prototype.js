define({
    name: 'prototype'
});