define(['specificCollection', 'bigCollection'], function (specificCollection, bigCollection) {

    return {
        name: 'app',
        specificCollection: specificCollection,
        bigCollection: bigCollection
    }
});
