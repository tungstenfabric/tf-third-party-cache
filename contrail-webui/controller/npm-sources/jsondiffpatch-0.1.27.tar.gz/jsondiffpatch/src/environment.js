
exports.isBrowser = typeof window !== 'undefined';
