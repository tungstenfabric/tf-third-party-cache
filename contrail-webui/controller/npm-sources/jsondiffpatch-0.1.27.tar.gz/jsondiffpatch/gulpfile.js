require('bulk-require')(__dirname + '/gulp-tasks', '*.js');
