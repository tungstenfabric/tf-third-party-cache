
  module.exports = debug;

})();