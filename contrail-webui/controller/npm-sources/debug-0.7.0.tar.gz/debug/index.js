
module.exports = require('./lib/debug');