
module.exports = require('./lib/kue');