"use strict";

if (module == require.main)
  require("test").run(exports);
