var globalLeafName = "leaf";

define("leaf", {
    name: globalLeafName
});
