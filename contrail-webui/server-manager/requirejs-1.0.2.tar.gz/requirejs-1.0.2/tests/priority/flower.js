define(function () {
    return {
        name: "flower"
    };
});
