define({
    red: "red, dude"
});
