log("nine.js script");
