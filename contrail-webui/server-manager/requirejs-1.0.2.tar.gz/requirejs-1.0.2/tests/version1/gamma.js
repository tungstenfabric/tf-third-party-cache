gamma = {
  color: "green"
}
