define("beta",
  function() {
    return {
      version: 1
    };
  }
);
