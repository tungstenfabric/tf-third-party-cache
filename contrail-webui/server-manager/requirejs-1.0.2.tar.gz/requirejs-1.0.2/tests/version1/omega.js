define("omega",
  function() {
    return {
      version: 1
    };
  }
);
