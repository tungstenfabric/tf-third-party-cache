//Stub file for testing optimization of all plugin resources in a build.
define(['text!resources/sample.html!strip'], function () {});
