define(['text!./resources/local.html'], function (localHtml) {
    return {
        localHtml: localHtml
    }
});
