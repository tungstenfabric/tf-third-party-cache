define("tres",
  function() {
    return {
      name: "tres"
    };
  }
);
