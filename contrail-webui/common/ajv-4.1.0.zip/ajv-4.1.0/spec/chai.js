module.exports = typeof window == 'object' ? window.chai : require('' + 'chai');
