pageTitle: AngularJS
menuTitle: AngularJS

If you're using [AngularJS](http://angularjs.org), check out the [AngularJS Generator](https://github.com/yeoman/generator-angular), which makes use of the [Karma Generator](https://github.com/yeoman/generator-karma) to setup a fully featured, testing-ready project.

Here is also a blog article explaining how to setup Grunt and Karma to test out an AngularJS application: [Full Spectrum Testing with AngularJS and Karma](http://www.yearofmoo.com/2013/01/full-spectrum-testing-with-angularjs-and-karma.html)
