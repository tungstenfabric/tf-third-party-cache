describe('something', function () {
  it('should never happen anyway', function () {
    expect(true).toBe(true)
  })
})
