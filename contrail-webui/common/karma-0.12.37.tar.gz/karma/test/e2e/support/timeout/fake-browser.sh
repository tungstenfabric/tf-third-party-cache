#!/bin/bash

read
