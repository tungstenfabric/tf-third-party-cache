// Some code under test, with syntax error
}}}}

function plus(a, b) {
  return a + b;
}
