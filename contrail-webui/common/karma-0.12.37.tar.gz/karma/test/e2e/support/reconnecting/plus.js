/* eslint-disable no-unused-vars */
// Some code under test
function plus (a, b) {
  return a + b
}
