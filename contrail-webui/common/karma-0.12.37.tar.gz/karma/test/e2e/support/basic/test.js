/* globals plus */
describe('plus', function () {
  it('should pass', function () {
    expect(true).toBe(true)
  })

  it('should work', function () {
    expect(plus(1, 2)).toBe(3)
  })
})
