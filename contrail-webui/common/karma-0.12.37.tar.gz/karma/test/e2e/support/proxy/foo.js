'/base/proxy/foo.js source'
