mocha --watch --reporter dot --compilers coffee:coffee-script test/unit/mocha-globals.coffee --recursive test/unit
