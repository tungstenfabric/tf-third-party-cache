module.exports = {
  VERSION: '%KARMA_VERSION%',
  KARMA_URL_ROOT: '%KARMA_URL_ROOT%',
  CONTEXT_URL: 'context.html'
}
