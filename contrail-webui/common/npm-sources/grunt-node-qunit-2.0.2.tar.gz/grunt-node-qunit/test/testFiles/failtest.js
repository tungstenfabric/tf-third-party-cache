test("a failing test", function(assert) {
    ok(false, "Just a test that fails");
});
