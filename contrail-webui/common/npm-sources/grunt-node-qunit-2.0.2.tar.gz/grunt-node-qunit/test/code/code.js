exports.CODE = function(){
	return 1;
}