exports.DEP = function(){
	return 1;
}