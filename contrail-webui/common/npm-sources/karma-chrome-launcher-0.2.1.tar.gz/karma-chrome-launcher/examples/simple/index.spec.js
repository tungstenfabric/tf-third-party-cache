describe('ChromeLauncher', function () {
  it('works', function () {
    1 + 1 === 2
  })
})
