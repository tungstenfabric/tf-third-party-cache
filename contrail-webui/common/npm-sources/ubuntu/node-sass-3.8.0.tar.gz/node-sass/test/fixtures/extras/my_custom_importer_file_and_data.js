module.exports = function() {
  return {
    file: '/some/random/path/file.scss',
    contents: 'div {color: yellow;}'
  };
};
