# karma-requirejs  [![Build Status](https://travis-ci.org/karma-runner/karma-requirejs.png?branch=master)](https://travis-ci.org/karma-runner/karma-requirejs)

> Adapter for the [RequireJS](http://requirejs.org/) framework.

Check out examples on how to configure RequireJS with Karma:
- Karma's e2e test https://github.com/karma-runner/karma/tree/master/test/e2e/requirejs
- Karma's docs http://karma-runner.github.io/0.8/plus/RequireJS.html
- Kim's example project https://github.com/kjbekkelund/karma-requirejs


----

For more information on Karma see the [homepage].


[homepage]: http://karma-runner.github.io/
