exports.whereFrom = function() {
    return "I was required as a namespace object";
};
