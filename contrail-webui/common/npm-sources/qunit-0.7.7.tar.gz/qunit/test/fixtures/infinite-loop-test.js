test('infinite loop', function() {
    ok(true)
})
