throw new Error('Some error.');
