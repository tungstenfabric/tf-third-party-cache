module.exports = require("./lib/testrunner");
