use cmon;
alter table mysql_slow_queries change qid qid bigint unsigned;
alter table mysql_slow_queries modify command varchar(16) default '';
alter table mysql_slow_queries modify state varchar(16) default '';
alter table mysql_explains change qid qid bigint unsigned;
alter table mysql_slow_queries drop primary key;
alter table mysql_slow_queries add primary key(cid, id, qid);
drop index mysql_slow_query on mysql_slow_queries;

