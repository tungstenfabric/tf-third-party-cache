alter table cluster change config_change config_change enum('RRM', 'RR','RRI','NONE') DEFAULT 'NONE';

