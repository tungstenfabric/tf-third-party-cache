use cmon;
alter table mysql_server add column status integer default '0';
alter table backup add column directory varchar(255);
