#mods fils 1.1.32 --> 1.1.33
use cmon;
#ALTER TABLE cmon_mysql_counters ADD COLUMN crc BIGINT UNSIGNED NOT NULL;
#ALTER TABLE cmon_mysql_counters DROP INDEX var;
#ALTER TABLE cmon_mysql_counters ADD UNIQUE INDEX (crc,var);
#ALTER TABLE cmon_mysql_counters ADD UNIQUE INDEX (var);
#ALTER TABLE cmon_mysql_counters ADD COLUMN rrd_gauge TINYINT DEFAULT '0';
alter table mysql_slow_queries change cnt cnt bigint unsigned default '0';
alter table mysql_query_histogram change cnt cnt bigint unsigned default '0';
