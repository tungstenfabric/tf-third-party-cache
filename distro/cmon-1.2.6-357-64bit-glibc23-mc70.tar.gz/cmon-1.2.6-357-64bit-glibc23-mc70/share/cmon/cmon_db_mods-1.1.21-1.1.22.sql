#
use cmon;
truncate table galera_status_history;

alter table mysql_states change description description varchar(255);