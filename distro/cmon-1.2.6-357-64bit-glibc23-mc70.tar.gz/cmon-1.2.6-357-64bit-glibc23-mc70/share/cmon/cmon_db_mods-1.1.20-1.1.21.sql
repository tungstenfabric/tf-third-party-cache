alter table hosts change ping_status ping_status integer not null default '0';
alter table hosts change ping_time ping_time integer not null default '0';
alter table hosts change msg msg varchar(255) not null default '';
alter table email_notification add column groupid integer default '0';
alter table mysql_processlist change state state varchar(128);
alter table mysql_performance_probes change statement statement blob;
alter table mysql_backup add column cc_storage tinyint default '0';