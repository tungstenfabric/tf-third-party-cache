alter table cmon_mysql_grants add column user varchar(260) DEFAULT NULL;
alter table cmon_mysql_grants add column host varchar(260) DEFAULT NULL;
