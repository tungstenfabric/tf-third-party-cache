use cmon;
INSERT IGNORE INTO mysql_states(id,name,description) VALUES(14, 'MYSQL_GALERA_READ_ONLY', 'Read-only during recovery (Donor)');
INSERT IGNORE INTO mysql_states(id,name,description) VALUES(15, 'MYSQL_GALERA_NODE_RECOVERING', 'Galera node recovery in progress');
