alter table cmon_mysql_counters add column gauge tinyint default 0;
drop index clusterid on cmon_job;
create index clusterid on cmon_job(cid, status);
alter table mysql_server add column failures integer default 0;
alter table cluster_state add column replication_state integer default 0;
alter table cluster_state add column prev_replication_state integer default 0;
