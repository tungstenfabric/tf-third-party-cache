#
use cmon;
# alter table cmon.mysql_server add column affinity bigint not null default '0';
alter table cmon.mysql_server add column progress_acct bigint not null default '0';
alter table cluster_state add column msg varchar(512) NOT NULL default '';
