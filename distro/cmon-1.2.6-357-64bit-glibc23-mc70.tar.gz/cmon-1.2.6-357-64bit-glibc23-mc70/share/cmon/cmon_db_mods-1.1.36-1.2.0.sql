use cmon;
alter table cluster_statistics add column  `lqhkey_overload` bigint(20) DEFAULT '0';
alter table cluster_statistics add column `lqhkey_overload_tc` bigint(20) DEFAULT '0';
alter table cluster_statistics add column   `lqhkey_overload_subscriber` bigint(20) DEFAULT '0';
alter table cluster_statistics add column   `lqhkey_overload_reader` bigint(20) DEFAULT '0';
alter table cluster_statistics add column   `lqhkey_overload_node_peer` bigint(20) DEFAULT '0';
alter table cluster_statistics add column   `lqhkey_overload_node_subscriber` bigint(20) DEFAULT '0';
alter table cluster_statistics add column   `lqhscan_slowdowns` bigint(20) DEFAULT '0';

alter table cluster_statistics_history add column  `lqhkey_overload` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column `lqhkey_overload_tc` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column   `lqhkey_overload_subscriber` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column   `lqhkey_overload_reader` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column   `lqhkey_overload_node_peer` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column   `lqhkey_overload_node_subscriber` bigint(20) DEFAULT '0';
alter table cluster_statistics_history add column   `lqhscan_slowdowns` bigint(20) DEFAULT '0';



alter table node_statistics add column  `lqhkey_overload` bigint(20) DEFAULT '0';
alter table node_statistics add column `lqhkey_overload_tc` bigint(20) DEFAULT '0';
alter table node_statistics add column   `lqhkey_overload_subscriber` bigint(20) DEFAULT '0';
alter table node_statistics add column   `lqhkey_overload_reader` bigint(20) DEFAULT '0';
alter table node_statistics add column   `lqhkey_overload_node_peer` bigint(20) DEFAULT '0';
alter table node_statistics add column   `lqhkey_overload_node_subscriber` bigint(20) DEFAULT '0';
alter table node_statistics add column   `lqhscan_slowdowns` bigint(20) DEFAULT '0';

alter table node_statistics_history add column  `lqhkey_overload` bigint(20) DEFAULT '0';
alter table node_statistics_history add column `lqhkey_overload_tc` bigint(20) DEFAULT '0';
alter table node_statistics_history add column   `lqhkey_overload_subscriber` bigint(20) DEFAULT '0';
alter table node_statistics_history add column   `lqhkey_overload_reader` bigint(20) DEFAULT '0';
alter table node_statistics_history add column   `lqhkey_overload_node_peer` bigint(20) DEFAULT '0';
alter table node_statistics_history add column   `lqhkey_overload_node_subscriber` bigint(20) DEFAULT '0';
alter table node_statistics_history add column   `lqhscan_slowdowns` bigint(20) DEFAULT '0';


alter table mysql_backup add column logfile text;



