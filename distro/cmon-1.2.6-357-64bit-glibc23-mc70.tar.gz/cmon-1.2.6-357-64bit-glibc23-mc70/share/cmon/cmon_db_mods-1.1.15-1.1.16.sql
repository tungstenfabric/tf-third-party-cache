use cmon;
DROP TABLE diskdata_history;
CREATE TABLE IF NOT EXISTS `diskdata_history` (
  `cid` int(11) NOT NULL,
  `nodeid` int(11) NOT NULL,
  `file_name` char(64) NOT NULL,
  `ts_name` char(64) NOT NULL,
  `type` char(64) NOT NULL,
  `logfile_group_name` char(64) NOT NULL,
  `free_extents` bigint(20) unsigned NOT NULL,
  `total_extents` bigint(20) unsigned NOT NULL,
  `extent_size` bigint(20) unsigned NOT NULL,
  `initial_size` bigint(20) unsigned NOT NULL,
  `maximum_size` bigint(20) unsigned NOT NULL,
  `undo_buffer_size` bigint(20) unsigned NOT NULL,
  `report_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`cid`,`nodeid`,`type`,`file_name`, `report_ts`),
  KEY `idx_diskhistory_free` (`free_extents`),
  KEY(`report_ts`, `cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

