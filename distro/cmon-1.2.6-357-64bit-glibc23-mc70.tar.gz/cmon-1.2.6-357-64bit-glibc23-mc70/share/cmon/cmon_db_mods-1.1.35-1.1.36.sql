use cmon;
ALTER TABLE mysql_backup ADD COLUMN md5sum VARCHAR(255) DEFAULT '';
/*alter table ext_proc add column active integer default 1;*/
/* alter table haproxy_server drop primary key; */
/* alter table haproxy_server add primary key (cid, lb_name, lb_host, lb_port) ; */


