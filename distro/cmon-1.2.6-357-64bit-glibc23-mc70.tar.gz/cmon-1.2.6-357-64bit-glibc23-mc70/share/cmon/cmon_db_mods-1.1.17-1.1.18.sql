alter table node_statistics_history add column local_writes bigint ;
alter table node_statistics add column local_writes bigint ;
alter table cluster_statistics add column local_writes bigint ;
alter table cluster_statistics_history add column local_writes bigint ;

