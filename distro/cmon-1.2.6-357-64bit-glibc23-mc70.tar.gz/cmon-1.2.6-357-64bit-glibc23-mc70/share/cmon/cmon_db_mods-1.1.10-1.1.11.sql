use cmon;
alter table mysql_slow_queries add column lock_time double default 0.0;
alter table mysql_slow_queries add column rows_sent integer unsigned default 0;
alter table mysql_slow_queries add column rows_examined integer unsigned default 0;
alter table mysql_slow_queries change column time time double default 0.0;
alter table mysql_slow_queries add column total_time double default 0.0;
alter table mysql_slow_queries add column total_lock_time double default 0.0;

