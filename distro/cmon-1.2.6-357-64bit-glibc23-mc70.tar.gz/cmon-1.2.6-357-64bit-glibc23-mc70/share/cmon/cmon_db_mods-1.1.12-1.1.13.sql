use cmon;
alter table cluster_state change status `status` enum('MGMD_NO_CONTACT','STARTED','NOT_STARTED','DEGRADED','FAILURE','SHUTTING_DOWN','RECOVERING','STARTING','UNKNOWN', 'STOPPED') DEFAULT NULL;
alter table cluster_state change previous_status `previous_status` enum('MGMD_NO_CONTACT','STARTED','NOT_STARTED','DEGRADED','FAILURE','SHUTTING_DOWN','RECOVERING','STARTING','UNKNOWN', 'STOPPED') DEFAULT NULL;
alter table node_statistics add column local_reads bigint DEFAULT '0';
alter table node_statistics_history add column local_reads bigint DEFAULT '0';
alter table cluster_statistics add column local_reads bigint DEFAULT '0';
alter table cluster_statistics_history add column local_reads bigint DEFAULT '0';


alter table node_statistics add column local_writes bigint DEFAULT '0';
alter table node_statistics_history add column local_writes bigint DEFAULT '0';
alter table cluster_statistics add column local_writes bigint DEFAULT '0';
alter table cluster_statistics_history add column local_writes bigint DEFAULT '0';
