use cmon;
ALTER TABLE mysql_backup ADD COLUMN compressed TINYINT DEFAULT '1';
alter table diskdata_history drop primary key;
alter table diskdata_history modify file_name varchar(4096);
alter table diskdata_history add primary key(cid,nodeid,file_name(512),report_ts);

alter table diskdata_history drop primary key;
alter table diskdata_history modify file_name varchar(4096);
alter table diskdata_history add primary key (cid,nodeid,file_name(512),report_ts);

alter table cmon_job add column user_id integer not null default '0';
alter table cmon_job modify jobspec varchar(8192);

alter table cluster add column parent_id integer NOT NULL DEFAULT '0';

