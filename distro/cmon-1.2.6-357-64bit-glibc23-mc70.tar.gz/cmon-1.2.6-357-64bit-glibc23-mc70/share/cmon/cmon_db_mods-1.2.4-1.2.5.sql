use cmon;
alter table mongodb_server add column pid integer not null default '0';