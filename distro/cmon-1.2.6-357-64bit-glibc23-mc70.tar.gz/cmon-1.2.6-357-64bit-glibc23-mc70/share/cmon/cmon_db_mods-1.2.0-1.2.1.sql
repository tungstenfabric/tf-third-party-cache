use cmon;
alter table mysql_backup add column storage_host varchar(255) default '';
alter table mysql_backup add column cc_storage tinyint default '0';
alter table backup_schedule add column cc_storage tinyint default '0';
alter table table_growth add column xengine varchar(64) default 'N/A';



