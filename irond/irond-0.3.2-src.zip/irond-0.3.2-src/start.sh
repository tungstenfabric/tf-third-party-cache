#!/bin/sh
java -jar irond.jar
